#ifndef VertexBuffer_h__
#define VertexBuffer_h__
#include <d3d11.h>
#include <wrl/client.h>
#include "AdapterReader.h"
#include "ConstantBufferTypes.h"
#include <memory>

template<class T>
class VertexBuffer
{
private:
	Microsoft::WRL::ComPtr<ID3D11Buffer> buffer;
	//ID3D11Buffer* bu[240];
	UINT bufferSize = 0;
	UINT stride=sizeof(T);
	std::vector<Vertex> vec;
public:
	VertexBuffer() {}
	//std::vector<Vertex> vecdx;
	ID3D11Buffer* Get()const
	{
		return buffer.Get();
	}

	ID3D11Buffer* const* GetAddressOf()const
	{
		return buffer.GetAddressOf();
	}

	UINT BufferSize() const
	{
		return this->bufferSize;
	}

	const UINT Stride() const
	{
		return this->stride;
	}

	const UINT * StridePtr() const
	{
		return &this->stride;
	}
	void bucle()
	{
		buffer.Reset();
		vec.clear();
	}
	HRESULT Initialize(ID3D11Device *device, T * data, UINT numVertices, std::vector<Vertex> vertices,bool tr)
	{
		bucle();
		this->bufferSize = numVertices;
		D3D11_BUFFER_DESC vertexBufferDesc;
		ZeroMemory(&vertexBufferDesc, sizeof(vertexBufferDesc));
		if (tr)
		{
			this->vec = vertices;
			vertexBufferDesc.Usage = D3D11_USAGE_DYNAMIC;//D3D11_USAGE_DEFAULT,D3D11_USAGE_DYNAMIC
			vertexBufferDesc.ByteWidth = stride * numVertices;
			vertexBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;//
			vertexBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;//0,D3D11_CPU_ACCESS_WRITE,
			vertexBufferDesc.MiscFlags = 0;
		}
		else
		{
			vertexBufferDesc.Usage = D3D11_USAGE_DEFAULT;//D3D11_USAGE_DEFAULT,D3D11_USAGE_DYNAMIC
			vertexBufferDesc.ByteWidth = stride * numVertices;
			vertexBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;//
			vertexBufferDesc.CPUAccessFlags = 0;//0,D3D11_CPU_ACCESS_WRITE,
			vertexBufferDesc.MiscFlags = 0;
		}
		D3D11_SUBRESOURCE_DATA vertexBufferData;
		ZeroMemory(&vertexBufferData, sizeof(vertexBufferData));
		vertexBufferData.pSysMem = data;
		HRESULT hr = device->CreateBuffer(&vertexBufferDesc, &vertexBufferData, this->buffer.ReleaseAndGetAddressOf());
		//for (int i = 0; i < 240; i++)
		//{
			//hr = device->CreateBuffer(&vertexBufferDesc, &vertexBufferData, &bu[i]);
		//}
		return hr;
	}
	void in(ID3D11DeviceContext * dev, std::vector<Vertex> vecdx)
	{
		D3D11_MAPPED_SUBRESOURCE mappedResource;
		dev->Map(buffer.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);//D3D11_MAP_WRITE_NO_OVERWRITE,D3D11_MAP_WRITE_DISCARD
		T* v = (T*)mappedResource.pData;
		for (int i = 0; i < vec.size(); i++)//8835,317
		{
			if (vec[i].pos.x <vecdx[i].pos.x)
			{
				vec[i].pos.x += 0.2f;
			}
			else if (vec[i].pos.x > vecdx[i].pos.x)
			{
				vec[i].pos.x -= 0.2f;
			}
			if (vec[i].pos.y < vecdx[i].pos.y)
			{
				vec[i].pos.y += 0.2f;
			}
			else if (vec[i].pos.y > vecdx[i].pos.y)
			{
				vec[i].pos.y -= 0.2f;
			}
			if (vec[i].pos.z < vecdx[i].pos.z)
			{
				//vecdx[i].pos.x -= 0.1f;
				vec[i].pos.z += 0.2f;
			}
			else if (vec[i].pos.z > vecdx[i].pos.z)
			{
				vec[i].pos.z -= 0.2f;
			}
			vec[i].texCoord = vecdx[i].texCoord;
			v[i] = vec[i];
		}
		dev->Unmap(buffer.Get(), 0);
	}
};

#endif // VertexBuffer_h__
