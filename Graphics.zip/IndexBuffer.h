#ifndef IndicesBuffer_h__
#define IndicesBuffer_h__
#include <d3d11.h>
#include <wrl/client.h>
#include "ConstantBufferTypes.h"
#include <vector>

class IndexBuffer
{
private:
	IndexBuffer(const IndexBuffer& rhs);

private:
	Microsoft::WRL::ComPtr<ID3D11Buffer> buffer;
	UINT bufferSize;
	std::vector<DWORD> ml;
public:
	IndexBuffer() {}
	ID3D11Buffer* Get()const
	{
		return buffer.Get();
	}

	ID3D11Buffer* const* GetAddressOf()const
	{
		return buffer.GetAddressOf();
	}

	UINT BufferSize() const
	{
		//return this->unber[TTG];
		return this->bufferSize;
	}
	void Bufcle()
	{
		buffer.Reset();
		ml.clear();
	}
	HRESULT Initialize(ID3D11Device *device, DWORD * data, UINT numIndices, std::vector<DWORD> indices,bool rt)
	{
		Bufcle();
		this->bufferSize = numIndices;
		D3D11_BUFFER_DESC indexBufferDesc;
		ZeroMemory(&indexBufferDesc, sizeof(indexBufferDesc));
		if (rt)
		{
			this->ml = indices;
			indexBufferDesc.Usage = D3D11_USAGE_DYNAMIC;//D3D11_USAGE_DYNAMIC,D3D11_USAGE_DEFAULT
			indexBufferDesc.ByteWidth = sizeof(DWORD)*numIndices;
			indexBufferDesc.BindFlags = D3D11_BIND_INDEX_BUFFER;
			indexBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;//0,D3D11_CPU_ACCESS_WRITE
			indexBufferDesc.MiscFlags = 0;
		}
		else
		{
			indexBufferDesc.Usage = D3D11_USAGE_DEFAULT;//D3D11_USAGE_DYNAMIC,D3D11_USAGE_DEFAULT
			indexBufferDesc.ByteWidth = sizeof(DWORD)*numIndices;
			indexBufferDesc.BindFlags = D3D11_BIND_INDEX_BUFFER;
			indexBufferDesc.CPUAccessFlags = 0;//0,D3D11_CPU_ACCESS_WRITE
			indexBufferDesc.MiscFlags = 0;
		}

		D3D11_SUBRESOURCE_DATA indexBufferData;
		ZeroMemory(&indexBufferData, sizeof(indexBufferData));
		indexBufferData.pSysMem = data;
		HRESULT hr = device->CreateBuffer(&indexBufferDesc, &indexBufferData, buffer.ReleaseAndGetAddressOf());
		return hr;
	}
	void in(ID3D11DeviceContext * dev, std::vector<DWORD> ind)
	{
		D3D11_MAPPED_SUBRESOURCE mappedResource;
		dev->Map(buffer.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);//D3D11_MAP_WRITE_NO_OVERWRITE,D3D11_MAP_WRITE_DISCARD
		DWORD* v = (DWORD*)mappedResource.pData;
		for (int i = 0; i < ind.size(); i++)
		{
			v[i] = ind[i];
		}
		dev->Unmap(buffer.Get(), 0);
	}
};

#endif // IndicesBuffer_h__