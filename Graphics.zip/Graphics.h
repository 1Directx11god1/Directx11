#pragma once
#include "AdapterReader.h"
#include "Shaders.h"
#include <SpriteBatch.h>
#include <SpriteFont.h>
#include <WICTextureLoader.h>
#include <btBulletDynamicsCommon.h>
#include <btBulletCollisionCommon.h>
#include <comdef.h>
#include <algorithm>
#include "Camera.h"
#include "Model.h"
#include "..\\Timer.h"
#include "ImGUI\\imgui.h"
#include "ImGUI\\imgui_impl_win32.h"
#include "ImGUI\\imgui_impl_dx11.h"

class Graphics
{
public:
	bool Initialize(HWND hwnd, int width, int height);
	void RenderFrame();
	Camera camera;
	Model model;
	XMFLOAT3* tt[5];
	XMFLOAT3* mlop[40];
	int q = 0;
	void rizemove(bool TR, int W, bool T,int TTF);
	void r(int n);
private:
	bool InitializeDirectX(HWND hwnd);
	bool InitializeShaders();
	bool InitializeScene();
	void cratshamp(float sha,float x, float y, float z, btScalar mass,int u);
	void cratshamp2(float sha, float x, float y, float z, btScalar mass, float u);
	void cratshamp3(float sha, float x, float y, float z, btScalar mass, float u, int dy);
	void cratshamp4(float shax, float x, float y, float z, btScalar mass, float shay,float shaz);
	void cratshamp5(float sha, float x, float y, float z, btScalar mass, float u);
	btScalar massfk = 0.4f;
	std::string cou = "";
	std::string op = "Data\\Objects\\1.fbx";//Data\\Objects\\1.fbx,nanosuit\\nanosuit.obj
	Microsoft::WRL::ComPtr<ID3D11Device> device;
	Microsoft::WRL::ComPtr<ID3D11DeviceContext> deviceContext;
	Microsoft::WRL::ComPtr<IDXGISwapChain> swapchain;
	Microsoft::WRL::ComPtr<ID3D11RenderTargetView> renderTargetView;

	VertexShader vertexshader;
	PixelShader pixelshader;
	ConstantBuffer<CB_VS_vertexshader> cb_vs_vertexshader;
	ConstantBuffer<CB_PS_pixelshader> cb_ps_pixelshader;

	void rize();
	void rizemodel();
	Model* a[3];
	//void rizemodelTTG();
	bool k = false;
	bool TRC = true;
	bool TRV = true;
	bool TRB = false;
	float g = 0.0f;
	int gh = 0;
	float shmk = 1.0f;
	int TTGGMF = 14;
	int TTEEEP = 40;
	int m = 0;
	int switch_on = 0;
	int sw[25];
	int ui = 0;
	int dynamint = 0;
	int lp = 0;
	int TTGGGG = 0;
	int TTGMMMM = 3;
	std::string coug = "TRC ST";
	std::string sbkwf = "linear";
	std::string stk = "bullet";
	Microsoft::WRL::ComPtr<ID3D11DepthStencilView> depthStencilView;
	Microsoft::WRL::ComPtr<ID3D11Texture2D> depthStencilBuffer;
	Microsoft::WRL::ComPtr<ID3D11DepthStencilState> depthStencilState;

	Microsoft::WRL::ComPtr<ID3D11RasterizerState> rasterizerState;
	Microsoft::WRL::ComPtr<ID3D11BlendState> blendState;

	std::unique_ptr<DirectX::SpriteBatch> spriteBatch;
	std::unique_ptr<DirectX::SpriteFont> spriteFont;

	Microsoft::WRL::ComPtr<ID3D11SamplerState> samplerState;
	int windowWidth = 0;
	int windowHeight = 0;
	Timer fpsTimer;
	//btDiscreteDynamicsWorld* dynam;
	btDynamicsWorld* dynam;
	//btDiscreteDynamicsWorld* dynam[20];
	btCollisionConfiguration* collisionConfig = new btDefaultCollisionConfiguration();
	btBroadphaseInterface* broadphase = new btDbvtBroadphase();
	btDispatcher* dispatcher= new btCollisionDispatcher(collisionConfig);
	btConstraintSolver* solver =new btSequentialImpulseConstraintSolver();
	int gra = -60;
	btTransform transsss;
	std::vector<btRigidBody*> ball;
	D3D11_SAMPLER_DESC sampDesc;
	int minn = 0;
	int maxx = 500;
};